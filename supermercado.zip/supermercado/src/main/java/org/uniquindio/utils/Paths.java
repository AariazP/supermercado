package org.uniquindio.utils;

public class Paths {

    public static final String INICIAR_SESION = "/view/iniciarsesion.fxml";
    public static final String VISTA_ADMIN = "/view/vistaAdmin.fxml";
    public static final String VISTA_CLIENTE = "/view/vistaCliente.fxml";
    public static final String VISTA_CAJERO = "/view/vistaCajero.fxml";
    public static final String VISTA_DOMICILIARIO = "/view/vistaDomiciliario.fxml";

}
