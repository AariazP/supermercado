package org.uniquindio.domain;

public interface Persona {

    public String getIdentificacion();
}
